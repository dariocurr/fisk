package risk;

/**
 * Enumerazione contenente tutti i possibili simboli delle carte.
 */
public enum Symbol {

    BISHOP, CANNON, JOKER, KNIGHT;

}
