package risk;

public class ConcreteSymbolCard extends SymbolCard {

    public ConcreteSymbolCard(Symbol symbol) {
        super(symbol);
    }

}
