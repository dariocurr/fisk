package risk;

public class ConcreteTerritoryCard extends TerritoryCard {

    public ConcreteTerritoryCard(Symbol symbol, Territory territory) {
        super(symbol, territory);
    }

}
