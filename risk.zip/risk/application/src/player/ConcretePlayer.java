package risk;

/**
 * Classe che concretizza un player.
 */
public class ConcretePlayer extends Player {

    public ConcretePlayer(String name, RiskColor color) {
        super(name, color);
    }

}
