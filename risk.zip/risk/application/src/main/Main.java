package risk;

public interface Main {

    public static void main(String... args) {
        Startable riskGUI = new StartRIskGUI();
        riskGUI.start();
    }
}
